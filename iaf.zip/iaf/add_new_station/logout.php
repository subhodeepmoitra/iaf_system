<?php
session_start();

$conn=mysqli_connect("sql304.epizy.com", "epiz_30660233", "XoJpJXRd2L6", "epiz_30660233_munics");
$a=$_GET['username'];
$b=$_GET['password'];
$c=$_GET['location'];
$d=$_GET['elevation'];
$e=$_GET['coordinates'];
$f=$_GET['runway'];
$g=$_GET['squadrons'];
$q="INSERT INTO `login`(`username`, `password`, `location_type`, `elevation`, `coordinates`, `runway`, `squadrons`) VALUES ('$a','$b','$c', '$d', '$e', '$f', '$g')";
$x=mysqli_query($conn,$q);
if($x==1)
{
    if(session_destroy()) // Destroying All Sessions {
        header("Location: ../index.php"); // Redirecting To Home Page
}
else
{
    header("location:Register.php?msg=NotDone");
}

//if(session_destroy()) // Destroying All Sessions {
//header("Location: index.php"); // Redirecting To Home Page

?>