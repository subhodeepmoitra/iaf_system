<?php
     include('login.php'); // Includes Login Script
     if(isset($_SESSION['login_user'])){
          header("location: Register.php"); // Redirecting To Profile Page
        }
?>
<!DOCTYPE html>
   <html>
       <head>
          <title>IAF HQ Login For New Station Registration</title>
          <link href="style.css" rel="stylesheet" type="text/css">
       </head>
    <body>
        <div id="login">
              <h2>IAF HQ Login For New Station Registration</h2>
              <form action="" method="post">
                  <label>User ID :</label>
                  <input id="name" name="username" placeholder="userid" type="text">
                  <label>Password :</label>
                  <input id="password" name="password" placeholder="**********" type="password"><br><br>
                  <input name="submit" type="submit" value=" Login ">
                  <span><?php echo $error; ?></span>
              </form>
        </div>
    </body>
</html>