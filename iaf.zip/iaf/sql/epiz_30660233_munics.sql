-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql304.epizy.com
-- Generation Time: Mar 16, 2022 at 11:19 PM
-- Server version: 10.3.27-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_30660233_munics`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `location_type` varchar(500) NOT NULL,
  `elevation` varchar(50) NOT NULL,
  `coordinates` varchar(500) NOT NULL,
  `runway` varchar(500) NOT NULL,
  `squadrons` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `location_type`, `elevation`, `coordinates`, `runway`, `squadrons`) VALUES
(1, 'test', 'test', '', '', '', '', ''),
(2, 'Barrackpore', 'bkp123', '', '18 feet / 5', '', '', ''),
(3, 'Panagarh', 'png123', '', '240 ft / 73 m', '', '', ''),
(6, 'test', 'test', 'test1', 'test1', 'test1', 'test1', 'test1'),
(7, 'Ambala', 'amb123', 'Ambala Air Force Station is considered one of the most strategically located bases of the IAF.', '275.2 m / 900 ft', '30Â°22â€²15â€³N 76Â°49â€²04â€³E', '9,224	2,811	Concrete / asphalt', '	No. 14 Squadron IAF No. 5 Squadron IAF No. 17 Squadron IAF'),
(8, 'Adampur ', 'adam123', 'Adampur Airport, Jalandhar is located at Adampur Town of Jalandhar district in Northern India. It is situated on the Jalandhar-Hoshiarpur main Highway 23 kilometers northeast of Jalandhar, Punjab. Adampur Airforce Station, Jalandhar is also situated here. It is the second largest military airbase of India. It lies within 100 km of the Indo-Pak Border and is home to No. 47 Squadron IAF and No. 223 Squadron IAF.', '775 ft / 236 m	', '31.434879Â°N 75.757256Â°E', '13/31	', '8 Wing, 47 Squadron, 223 Squadron');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
